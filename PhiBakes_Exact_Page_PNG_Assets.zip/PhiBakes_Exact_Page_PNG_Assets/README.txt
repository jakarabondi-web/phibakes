PhiBakes Exact Page PNG Asset Package
=========================================

Source
------
All assets were extracted from the supplied Phibakes.png reference screenshot
(724 x 2172 pixels). The original full-page reference is included as
00_reference/phibakes-full-page-reference.png.

Contents
--------
- 01_brand: PhiBakes wordmark reference
- 02_hero: hero cake scene
- 03_trust-icons: four trust-strip icon crops
- 04_categories: six category images
- 05_how-it-works: five process icon crops
- 06_featured: four featured-cake product images
- 07_custom: custom-cake promotional collection
- 08_ready-today: three ready-today product images
- 09_testimonials: three customer portraits
- 10_delivery: Nairobi delivery-map artwork
- 11_social-gallery: six social-gallery images
- 12_misc: newsletter and payment visuals
- asset-manifest.csv: filenames, pixel dimensions, and source coordinates

Important quality note
----------------------
These are exact crops from the supplied screenshot, not the original source
photographs. Their resolution is limited by the 724-pixel-wide reference image.
They are ideal for faithfully rebuilding this exact mockup at its reference size.
For a high-DPI production website, replace photography with licensed original
high-resolution files while retaining these crops as visual references.
